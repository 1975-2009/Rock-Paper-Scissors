import random

def rockPaperScissors(x,user,com,users):

        if user==x:
            print("Draw")
        elif user==1:
            if x==2:
                print("Computer Wins")
                com=com+1
        elif x==3:
            print(" You win")
            users=users+1
        elif user==2 and x==3:
            print("Computer Wins")
            com=com+1
        elif user==2 and x==1:
            print("You Win")
            users=users+1
        elif user==3 and x==1:
            print("Computer Wins")
            com=com+1
        elif user==3 and x==2:
            print("You Win")
            users=users+1
        else:
            print("Error")

        return (com,users)
#main
users=0
com=0

c=int(input("How many games do you want to play?: "))
c=c*6

for i in range (c):
    x=random.randint(1,3)
    print("COMPUTER IS",x)
    user=int(input("First to three. Enter Rock (1), Paper(2) or Scissors(3): "))
    com,users=rockPaperScissors(x,user,com, users)
if users==3:
    print("Final: You Win!")
elif com==3:
    print("Final: Tough Luck.")
